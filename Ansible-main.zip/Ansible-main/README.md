# Ansible

My Ansible tutorials, can be used by beginners. Ansible is so much light weight and is very easy to learn. We should be able to write decent playbooks with very short learning curve. 

All the best...
