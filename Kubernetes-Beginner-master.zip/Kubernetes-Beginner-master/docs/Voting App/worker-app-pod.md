!!! Example "worker-app-pod.yaml"

    ```yaml
    apiVersion: v1
    kind: Pod
    metadata:
      name: worker-app-pod
      labels:
        name: worker-app-pod
        app: demo-voting-app
    spec:
      containers:
        - name: worker-app
          image: kodekloud/examplevotingapp_worker:v1
    ```      
