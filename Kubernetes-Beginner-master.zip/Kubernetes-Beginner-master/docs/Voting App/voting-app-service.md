!!! Example "voting-app-service.yaml"

    ```yaml
    apiVersion: v1
    kind: Service
    metadata:
      name: voting-service
      labels:
        name: voting-service
        app: demo-voting-app
    spec:
      type: NodePort
      ports:
      - port: 80
        targetPort: 80
        nodePort: 30004
      selector:
        name: voting-app-pod
        app: demo-voting-app
    ```