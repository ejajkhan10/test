!!! Example "redis-app-service.yaml"

    ```yaml
    apiVersion: v1
    kind: Service
    metadata:
      name: result-service
      labels:
        name: result-service
        app: demo-voting-app
    spec:
      type: NodePort
      ports:
      - port: 80
        targetPort: 80
        nodePort: 30005
      selector:
        name: result-app-pod
        app: demo-voting-app
    ```