!!! Example "nginx.yaml"

    ```yaml
    apiVersion: v1
    kind: Pod
    metadata: 
      name: nginx-2
      labels: 
        app: myapp
    spec:
      containers:
        - name: nginx
          image: nginx
    ```