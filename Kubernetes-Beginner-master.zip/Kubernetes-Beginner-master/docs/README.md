# Kubernetes-Beginner
Kubernetes for the absolute begineers

[https://bhavyasree.github.io/Kubernetes-Beginner](https://bhavyasree.github.io/Kubernetes-Beginner)
