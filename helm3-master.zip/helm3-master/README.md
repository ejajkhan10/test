# Packaging Applications with Helm for Kubernetes course  @ Pluralsight
Ressources for "Packaging Applications with Helm for Kubernetes" @ Pluralsight (Helm version 3)
