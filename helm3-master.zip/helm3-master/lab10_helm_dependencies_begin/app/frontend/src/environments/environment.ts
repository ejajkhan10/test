export const environment = {
    production: true,
    guestBookName: '{{GUESTBOOK_NAME}}',
    backendUri: '{{BACKEND_URI}}'
};
